<html>
<body>

<form action="welcome.php" method="post">

E-mail<br>
 <input type="text" name="email"><br>
<input type="submit">
</form>

</body>
</html>